"""Native Anthropic adapter. Optional: requires `pip install mklang[anthropic]`.

`reason: true` maps to adaptive thinking (per the current Claude API — no
budget_tokens on Opus 4.7+/Sonnet 5); the summarized thinking is captured as
`reasoning`."""

from __future__ import annotations

import time
from typing import Any

from ..errors import CancellationError, JudgeUnparseable, ProviderError, RefusalError
from .base import (
    JUDGE_CONTEXT_CHARS,
    JUDGE_SYSTEM,
    TRANSIENT_STATUS,
    LLMDelta,
    LLMEvent,
    Produced,
    build_judge_user,
    is_connection_error,
    is_length_stop,
    parse_choice,
)
from .context_view import format_judge_context


class AnthropicLLM:
    def __init__(self, api_key: str, base_url: str | None = None, max_retries: int = 3):
        import anthropic  # lazy: only needed when this provider is active

        # base_url is accepted for API symmetry with other providers; the SDK
        # picks it up via env / client options when needed.
        kwargs: dict = {"api_key": api_key or None}
        if base_url:
            kwargs["base_url"] = base_url
        self.client = anthropic.Anthropic(**kwargs)
        self.max_retries = max_retries

    def close(self) -> None:
        """Close the SDK client, interrupting any in-flight console request."""
        self.client.close()

    def _create(self, *, on_event: LLMEvent | None = None, **kwargs: Any) -> Any:
        """messages.create with transient retry and param drop-on-reject."""
        attempt = 0
        while True:
            try:
                return self.client.messages.create(**kwargs)
            except RefusalError:
                raise
            except Exception as e:  # classify, then retry or wrap
                # Refusal may surface as an API payload rather than our type.
                if getattr(e, "stop_reason", None) == "refusal":
                    raise RefusalError("the model declined this request") from e
                status = getattr(e, "status_code", None)
                msg = str(e).lower()
                transient = status in TRANSIENT_STATUS or is_connection_error(e)
                if transient and attempt < self.max_retries:
                    _notify(on_event, "retry", attempt=attempt + 1, status=status)
                    time.sleep(0.5 * 2**attempt)
                    attempt += 1
                    continue
                if _drop_offending_param(kwargs, msg):
                    continue
                raise ProviderError(str(e)) from e

    def _stream_create(
        self, kwargs: dict, *, on_event: LLMEvent | None = None, on_delta: LLMDelta
    ) -> Produced:
        attempt = 0
        while True:
            try:
                text: list[str] = []
                reasoning: list[str] = []
                with self.client.messages.stream(**kwargs) as stream:
                    for event in stream:
                        if getattr(event, "type", None) != "content_block_delta":
                            continue
                        delta = getattr(event, "delta", None)
                        kind = getattr(delta, "type", None)
                        value = getattr(delta, "text", None) or getattr(delta, "thinking", None)
                        if not value:
                            continue
                        if kind == "thinking_delta":
                            reasoning.append(value)
                            on_delta(value, "reasoning")
                        elif kind == "text_delta":
                            text.append(value)
                            on_delta(value, "content")
                    message = stream.get_final_message()
                usage = getattr(message, "usage", None)
                return Produced(
                    text="".join(text).strip(),
                    reasoning="".join(reasoning) or None,
                    input_tokens=getattr(usage, "input_tokens", 0) if usage else 0,
                    output_tokens=getattr(usage, "output_tokens", 0) if usage else 0,
                    truncated=is_length_stop(getattr(message, "stop_reason", None)),
                    finish_reason=getattr(message, "stop_reason", None),
                )
            except Exception as e:
                if isinstance(e, CancellationError):
                    raise
                status = getattr(e, "status_code", None)
                transient = status in TRANSIENT_STATUS or is_connection_error(e)
                if transient and attempt < self.max_retries:
                    _notify(on_event, "retry", attempt=attempt + 1, status=status)
                    time.sleep(0.5 * 2**attempt)
                    attempt += 1
                    continue
                raise ProviderError(str(e)) from e

    def produce(
        self,
        model: str,
        system: str,
        user: str,
        reason: bool = False,
        temperature: float = 0.4,
        params: dict | None = None,
        on_event: LLMEvent | None = None,
        on_delta: LLMDelta | None = None,
    ) -> Produced:
        params = params or {}
        kwargs: dict = {
            "model": model,
            "max_tokens": 4096,
            "system": system,
            "messages": [{"role": "user", "content": user}],
        }
        # thinking: `reason` turns it on; config `thinking` can force adaptive/disabled.
        thinking = params.get("thinking")
        thinking_on = False
        if thinking == "disabled":
            pass
        elif reason or thinking == "adaptive":
            kwargs["thinking"] = {"type": "adaptive", "display": "summarized"}
            thinking_on = True
        # Anthropic rejects temperature alongside thinking; apply only when off.
        if not thinking_on:
            kwargs["temperature"] = temperature
        if "effort" in params:  # low | medium | high | xhigh | max
            kwargs["output_config"] = {"effort": params["effort"]}
        if on_delta is not None:
            return self._stream_create(kwargs, on_event=on_event, on_delta=on_delta)
        msg = self._create(on_event=on_event, **kwargs)
        stop = getattr(msg, "stop_reason", None)
        if stop == "refusal":
            raise RefusalError("the model declined this request")
        text, reasoning = "", None
        for block in msg.content:
            if block.type == "text":
                text += block.text
            elif block.type == "thinking":
                reasoning = getattr(block, "thinking", None) or reasoning
        u = getattr(msg, "usage", None)
        it = getattr(u, "input_tokens", 0) if u else 0
        ot = getattr(u, "output_tokens", 0) if u else 0
        return Produced(
            text=text.strip(),
            reasoning=reasoning,
            input_tokens=it,
            output_tokens=ot,
            truncated=is_length_stop(stop),
            finish_reason=stop,
        )

    def judge(
        self,
        model: str,
        conditions: list[str],
        output: str,
        context: dict,
        reasoning: str | None = None,
        allow_none: bool = False,
        on_event: LLMEvent | None = None,
    ) -> tuple[int, str | None]:
        user = build_judge_user(
            conditions,
            output,
            format_judge_context(context, JUDGE_CONTEXT_CHARS),
            reasoning=reasoning,
            allow_none=allow_none,
        )
        msg = self._create(
            on_event=on_event,
            model=model,
            max_tokens=64,
            system=JUDGE_SYSTEM,
            messages=[{"role": "user", "content": user}],
            temperature=0,
        )
        text = "".join(b.text for b in msg.content if b.type == "text")
        idx, method = parse_choice(text, len(conditions) + (1 if allow_none else 0))
        if idx is None:
            raise JudgeUnparseable(text[:200] or "(empty)")
        usage = getattr(msg, "usage", None)
        self.last_judge_usage = (
            getattr(usage, "input_tokens", 0) or 0,
            getattr(usage, "output_tokens", 0) or 0,
        )
        return idx, method


def _drop_offending_param(kwargs: dict, err_msg: str) -> bool:
    """Drop the first rejected top-level field so the caller can retry once."""
    for name in ("temperature", "thinking", "output_config", "max_tokens"):
        if name in kwargs and name in err_msg:
            kwargs.pop(name, None)
            return True
    return False


def _notify(callback: LLMEvent | None, event: str, **fields: object) -> None:
    if callback is not None:
        callback({"event": event, **fields})
