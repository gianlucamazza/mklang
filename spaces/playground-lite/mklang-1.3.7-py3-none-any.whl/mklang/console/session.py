"""Console session persistence (ADR 0015 M2c): plain JSON files, crash-tolerant.

A session directory holds `state.json` (rewritten atomically at each turn's
end), `transcript.jsonl` (streaming append: turns and run events), and
`checkpoints/` for suspended runs. Nothing beyond the standard library.

Brain prompt history is windowed separately (ADR 0017): the full transcript and
``Session.history`` remain the audit trail; only the view passed into
``agent.mkl`` is capped.
"""

from __future__ import annotations

import json
import os
import re
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path


def default_base() -> Path:
    from ..paths import host_paths

    return host_paths().sessions


# Kept as a compatibility symbol; runtime callers use ``default_base()`` so
# XDG/MKLANG overrides made after import are still honored.
DEFAULT_BASE = default_base()

# Prompt-side budget for the brain's {{history}} (not the on-disk audit).
HISTORY_CHARS = 8_000
HISTORY_TURNS = 12
_TURN_SPLIT = re.compile(r"(?=^user: )", re.M)


@dataclass
class Session:
    dir: Path
    created_at: str = field(
        default_factory=lambda: datetime.now().isoformat(timespec="microseconds")
    )
    history: str = ""
    spent_in: int = 0
    spent_out: int = 0
    consented: list[str] = field(default_factory=list)
    always_yes: bool = False
    workspace: str = ""
    brain: str = ""
    task: dict = field(default_factory=dict)
    _lock: threading.RLock = field(default_factory=threading.RLock, init=False, repr=False)

    # -- lifecycle ---------------------------------------------------------

    @classmethod
    def create(
        cls, base: Path | str | None = None, workspace: str = "", brain: str = ""
    ) -> Session:
        base = default_base() if base is None else Path(base)
        sid = datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:4]
        d = Path(base) / sid
        (d / "checkpoints").mkdir(parents=True, exist_ok=True)
        s = cls(dir=d, workspace=workspace, brain=brain)
        s.save_state()
        return s

    @classmethod
    def load(cls, d: Path | str) -> Session:
        d = Path(d)
        st = json.loads((d / "state.json").read_text(encoding="utf-8"))
        if not isinstance(st, dict):
            raise ValueError("session state must be a JSON object")
        history = st.get("history", "")
        spent_in = st.get("spent_in", 0)
        spent_out = st.get("spent_out", 0)
        consented = st.get("consented", [])
        workspace = st.get("workspace", "")
        brain = st.get("brain", "")
        task = st.get("task", {})
        if (
            not isinstance(history, str)
            or not isinstance(spent_in, int)
            or not isinstance(spent_out, int)
        ):
            raise ValueError("invalid session counters or history")
        if (
            spent_in < 0
            or spent_out < 0
            or not isinstance(consented, list)
            or not all(isinstance(item, str) for item in consented)
        ):
            raise ValueError("invalid session consent or counters")
        if (
            not isinstance(workspace, str)
            or not isinstance(brain, str)
            or not isinstance(task, dict)
        ):
            raise ValueError("invalid session metadata")
        return cls(
            dir=d,
            created_at=str(
                st.get("created_at") or datetime.fromtimestamp(d.stat().st_mtime).isoformat()
            ),
            history=history,
            spent_in=spent_in,
            spent_out=spent_out,
            consented=list(consented),
            always_yes=bool(st.get("always_yes", False)),
            workspace=workspace,
            brain=brain,
            task=dict(task),
        )

    @classmethod
    def latest(
        cls, base: Path | str | None = None, *, workspace: str | Path | None = None
    ) -> Session | None:
        base = default_base() if base is None else Path(base)
        if not base.is_dir():
            return None
        expected = str(Path(workspace).expanduser().resolve()) if workspace is not None else None
        candidates = []
        for path in base.iterdir():
            if not (path / "state.json").is_file():
                continue
            if expected is not None:
                try:
                    state = json.loads((path / "state.json").read_text(encoding="utf-8"))
                except (OSError, ValueError):
                    continue
                recorded = state.get("workspace")
                if not recorded or str(Path(recorded).expanduser().resolve()) != expected:
                    continue
            candidates.append(path)
        if not candidates:
            return None
        sessions = []
        for path in candidates:
            try:
                sessions.append(cls.load(path))
            except (OSError, TypeError, ValueError, UnicodeDecodeError):
                continue
        if not sessions:
            return None
        return max(sessions, key=lambda session: (session.created_at, session.id))

    # -- persistence -------------------------------------------------------

    @property
    def id(self) -> str:
        return self.dir.name

    @property
    def checkpoints_dir(self) -> Path:
        return self.dir / "checkpoints"

    def save_state(self) -> None:
        with self._lock:
            payload = {
                "created_at": self.created_at,
                "history": self.history,
                "spent_in": self.spent_in,
                "spent_out": self.spent_out,
                "consented": sorted(self.consented),
                "always_yes": self.always_yes,
                "workspace": self.workspace,
                "brain": self.brain,
                "task": self.task,
            }
            tmp = self.dir / "state.json.tmp"
            tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            os.replace(tmp, self.dir / "state.json")

    def append(self, record: dict) -> None:
        with self._lock, (self.dir / "transcript.jsonl").open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")

    def records(self) -> list[dict]:
        """Read recoverable transcript records, tolerating a torn final line."""
        path = self.dir / "transcript.jsonl"
        if not path.is_file():
            return []
        records: list[dict] = []
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except (OSError, UnicodeDecodeError):
            return []
        for line in lines:
            try:
                value = json.loads(line)
            except (TypeError, ValueError):
                continue
            if isinstance(value, dict):
                records.append(value)
        return records


def history_for_brain(
    history: str,
    *,
    max_chars: int = HISTORY_CHARS,
    max_turns: int = HISTORY_TURNS,
) -> str:
    """Window conversation history for injection into the brain prompt.

    Keeps the **last** ``max_turns`` user/agent blocks and hard-caps characters.
    When anything is dropped, prefixes an explicit ``…[history_truncated…]…``
    marker so the model (and authors) can see the cut. The full history stays
    in ``Session.history`` / transcript for audit — this is prompt-only.
    """
    text = (history or "").strip()
    if not text:
        return ""
    # Turn blocks are written as "user: …\nagent: …" (see app.finish_turn).
    blocks = [b.strip() for b in _TURN_SPLIT.split(text) if b.strip()]
    if not blocks:
        return _tail_chars(text, max_chars, truncated=False)

    truncated_turns = False
    if max_turns > 0 and len(blocks) > max_turns:
        blocks = blocks[-max_turns:]
        truncated_turns = True
    body = "\n".join(blocks)
    if max_chars > 0 and len(body) > max_chars:
        return _tail_chars(body, max_chars, truncated=True)
    if truncated_turns:
        return f"…[history_truncated, kept last {max_turns} turns]…\n{body}"
    return body


def _tail_chars(text: str, max_chars: int, *, truncated: bool) -> str:
    if max_chars <= 0:
        return "…[history_truncated]…"
    if not truncated and len(text) <= max_chars:
        return text
    marker = "…[history_truncated]…"
    if len(marker) >= max_chars:
        return marker[:max_chars]
    return marker + text[-(max_chars - len(marker)) :]
