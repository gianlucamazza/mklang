"""The mklang console TUI (ADR 0015 M1): agent-first, brain-as-machine.

Textual TUI, bundled by default since 0.15.0. The engine runs on a worker
thread; `TextualBridge` (`bridge.py`) marshals events into the UI and blocks the worker on
human questions (HITL escalations, tool consent) answered through the main
input line. Nothing here adds semantics: the brain is `agent.mkl`, the hands
are `ConsoleTools`, and the run tree is the `on_event` stream.
"""

from __future__ import annotations

import contextlib
import os
import threading
import time
import traceback
from collections.abc import Callable
from dataclasses import replace as dc_replace
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, ClassVar, cast

import yaml

from ..checkpoint import save_checkpoint
from ..engine import RunResult
from ..engine import run as run_engine
from ..hooks import load_hook_registry
from ..loader import validate_dict
from ..model import Machine, parse_machine
from . import render as log_render
from .bridge import TextualBridge
from .tools import ConsoleTools
from .workspace import requires_workspace_inspection

_DEFAULT_COST_BUDGET = object()

if TYPE_CHECKING:
    from textual.app import App

    from ..llm.base import LLM


def load_brain(agent_path: str | None = None) -> Machine:
    """The bundled agent.mkl, or a user-supplied brain honoring the tool contract."""
    if agent_path is not None:
        text = Path(agent_path).read_text(encoding="utf-8")
    else:
        from importlib.resources import files

        text = files("mklang").joinpath("data/console/agent.mkl").read_text(encoding="utf-8")
    doc = yaml.safe_load(text)
    validate_dict(doc)
    return parse_machine(doc)


def stream_cancel_mode() -> str:
    """Resolve the console's provider-stream cancellation policy."""
    mode = os.environ.get("MKLANG_STREAM_CANCEL", "immediate").strip().lower()
    if mode not in ("cooperative", "immediate"):
        raise ValueError(f"MKLANG_STREAM_CANCEL must be 'cooperative' or 'immediate', got {mode!r}")
    return mode


def build_app(
    config: str,
    provider: str | None,
    workspace: str,
    agent_path: str | None = None,
    build_llm: Callable[[object], LLM] | None = None,
    session_base: str | None = None,
    continue_session: bool = False,
    session_id: str | None = None,
) -> App:
    """Construct the Textual app (imported lazily so the core stays TUI-free)."""
    from rich.console import RenderableType
    from textual.app import App, ComposeResult
    from textual.containers import Horizontal, Vertical
    from textual.suggester import SuggestFromList
    from textual.widgets import Footer, Header, Input, RichLog, Static

    from .session import Session, default_base
    from .widgets import ActivityTree, Inspector

    brain = load_brain(agent_path)
    base = Path(session_base) if session_base else default_base()

    class ConsoleApp(App):
        TITLE = "mklang console"
        CSS = """
        Screen { layout: vertical; background: $background; }
        Header { background: $surface; color: $text; }
        Footer { background: $surface; color: $text-muted; }
        #body { height: 1fr; min-height: 8; }
        #main { width: 2fr; min-width: 32; }
        #log {
            height: 1fr; padding: 1 2; scrollbar-gutter: stable;
            border: solid $panel; background: $surface;
        }
        #activity {
            height: 8; min-height: 4; border: solid $panel;
            padding: 0 1; background: $background;
        }
        #activity-live {
            height: 4; min-height: 2; padding: 0 1;
            border: solid $panel; background: $surface; overflow-y: auto;
        }
        #activity.hidden, #activity-live.hidden { display: none; }
        #status {
            height: 2; padding: 0 2; color: $text-muted;
            background: $boost; content-align: left middle;
        }
        #status.ready { color: $success; }
        #status.running { color: $primary; }
        #status.waiting { color: $warning; }
        #status.stopping { color: $warning; }
        #status.error { color: $error; }
        #prompt { height: 3; border: solid $primary; padding: 0 1; background: $surface; }
        #prompt:focus { border: double $primary; }
        #prompt.answer-mode { border: double $warning; background: $panel; }
        #prompt:disabled { color: $text-muted; border: solid $panel; }
        #inspector { width: 40%; border: solid $panel; background: $surface; }
        #inspector-tabs { height: 1fr; }
        #inspector-tabs Tab { padding: 0 2; }
        #inspector-tabs Tab.-active { color: $text; background: $panel; text-style: bold; }
        #inspector-context, #inspector-trace { padding: 1 2; }
        #inspector-session { padding: 2; overflow-y: auto; }
        """
        # Textual's App.BINDINGS is a list of Binding | 2-tuple | 3-tuple;
        # keep the ClassVar loose enough for mypy variance (RUF012).
        BINDINGS: ClassVar[list] = [
            ("ctrl+c", "quit", "Quit"),
            ("f2", "toggle_inspector", "Inspector"),
            ("ctrl+t", "toggle_activity", "Activity"),
            ("ctrl+g", "cancel_run", "Stop"),
            ("ctrl+l", "clear_log", "Clear"),
        ]

        def __init__(self):
            super().__init__()
            self.bridge = TextualBridge(self)
            self.cancel_event = threading.Event()
            self.stream_cancel = stream_cancel_mode()
            self.tools = ConsoleTools(
                config=config,
                provider=provider,
                bridge=self.bridge,
                workspace=Path(workspace),
                build_llm=build_llm,
                cancel_requested=self.cancel_event.is_set,
            )
            if session_id:
                candidate = (base / session_id).resolve()
                if not candidate.is_relative_to(base.resolve()):
                    raise ValueError("session id must stay inside the console session directory")
                self.session = Session.load(candidate)
                if (
                    self.session.workspace
                    and Path(self.session.workspace).resolve() != self.tools.workspace
                ):
                    raise ValueError(
                        f"session {session_id!r} belongs to workspace {self.session.workspace!r}, "
                        f"not {self.tools.workspace}"
                    )
            elif continue_session:
                self.session = Session.latest(
                    base, workspace=self.tools.workspace
                ) or Session.create(
                    base,
                    workspace=str(self.tools.workspace),
                    brain=brain.name,
                )
            else:
                self.session = Session.create(
                    base, workspace=str(self.tools.workspace), brain=brain.name
                )
            self.history = self.session.history
            self.tools.audit = lambda record: self.session.append({"t": "audit", **record})
            self.tools.task = self.session.task
            self.tools.task_persist = self.session.save_state
            self.spent_in = self.session.spent_in
            self.spent_out = self.session.spent_out
            self.tools.restore_consented(self.session.consented)
            self.bridge.always_yes = self.session.always_yes
            self.answer_mode = False
            self.running = False
            self.shutting_down = False
            self._worker_done = threading.Event()
            self._worker_done.set()
            self.activity_visible = True
            self.inspector_visible = False
            self.current_phase = ""
            self.current_limits: dict = {}
            self.log_history: list[str] = []  # plain mirror of the log, for tests
            self._live_request: dict = {}

        def compose(self) -> ComposeResult:
            yield Header(show_clock=False)
            yield Static("", id="status")
            with Horizontal(id="body"):
                with Vertical(id="main"):
                    # markup=False: untrusted content never rides Rich tags via write(str).
                    # Chrome uses Text.from_markup / Markdown renderables instead.
                    yield RichLog(id="log", wrap=True, markup=False)
                    yield ActivityTree()
                    yield Static(log_render.activity_live_idle(), id="activity-live")
                    from .commands import COMMANDS

                    yield Input(
                        placeholder="Ask the agent or type / for commands",
                        id="prompt",
                        suggester=SuggestFromList(
                            [f"/{command.name}" for command in COMMANDS], case_sensitive=False
                        ),
                    )
                yield Inspector()
            yield Footer()

        def action_toggle_inspector(self) -> None:
            self.inspector_visible = not self.inspector_visible
            self.apply_responsive_layout()

        def action_toggle_activity(self) -> None:
            self.activity_visible = not self.activity_visible
            self.query_one(ActivityTree).set_class(not self.activity_visible, "hidden")
            self.query_one("#activity-live", Static).set_class(not self.activity_visible, "hidden")

        def action_cancel_run(self) -> None:
            if not self.running or self.answer_mode:
                return
            self.cancel_event.set()
            if self.stream_cancel == "immediate":
                try:
                    self.tools.interrupt_provider()
                except Exception as exc:
                    self.log_chrome(
                        f"[red]Provider transport interruption failed: {type(exc).__name__}[/red]"
                    )
            message = (
                "Stop requested — interrupting the provider transport…"
                if self.stream_cancel == "immediate"
                else "Stop requested — waiting for the current state to finish…"
            )
            self.log_chrome(f"[yellow]{message}[/yellow]")
            self.update_status("stopping")

        async def action_quit(self) -> None:
            """Stop the active run cleanly before Textual tears down its event loop."""
            self._begin_shutdown()
            if await self._wait_for_worker():
                self.exit()
            else:
                self.log_chrome(
                    "[b red]The worker did not stop within 30 seconds; "
                    "keeping the console open.[/b red]"
                )
                self.update_status("error")

        async def on_unmount(self) -> None:
            """Cover SIGINT and other exits which bypass the ``quit`` action."""
            self._begin_shutdown()
            await self._wait_for_worker()

        def _begin_shutdown(self) -> None:
            if self.shutting_down:
                return
            self.shutting_down = True
            self.cancel_event.set()
            self.bridge.cancel()
            # Shutdown must still release the console if a third-party
            # provider implements a broken optional close hook.
            with contextlib.suppress(Exception):
                self.tools.close()

        async def _wait_for_worker(self) -> bool:
            import asyncio

            deadline = asyncio.get_running_loop().time() + 30
            while not self._worker_done.is_set() and asyncio.get_running_loop().time() < deadline:
                await asyncio.sleep(0.01)
            return self._worker_done.is_set()

        def _run_thread_worker(self, work: Callable[[], object]) -> None:
            """Start work and track the backing thread, not only Textual's task."""
            self._worker_done.clear()

            def tracked_work():
                try:
                    return work()
                except Exception as exc:
                    if not self.shutting_down:
                        self.call_from_thread(self.finish_worker_error, exc, traceback.format_exc())
                finally:
                    self._worker_done.set()

            self.run_worker(tracked_work, thread=True, exclusive=True)

        def action_clear_log(self) -> None:
            self.query_one("#log", RichLog).clear()
            self.log_history.clear()

        def on_mount(self) -> None:
            self.log_chrome(
                "[b]Ready.[/b] Ask the agent what should happen, or type [cyan]/help[/cyan]."
            )
            if self.history:
                self.log_chrome(
                    f"[dim]resumed session with {len(self.history)} chars of history[/dim]"
                )
                self.replay_session()
            self.update_status("ready")
            self.query_one(Inspector).show_session(
                self.session, self.spent_in, self.spent_out, self.tools.consented
            )
            self.query_one(Inspector).show_empty()
            self.apply_responsive_layout()
            self.query_one("#prompt", Input).focus()
            self.set_interval(0.25, self.refresh_live_activity)

        def replay_session(self) -> None:
            """Restore the visible conversation from the append-only transcript."""
            for record in self.session.records():
                kind = record.get("t")
                if kind == "user":
                    self.log_plain(
                        str(record.get("text", "")),
                        label_markup="[b cyan]you:[/b cyan] ",
                        mirror_label="you:",
                    )
                elif kind == "agent":
                    body = str(record.get("text", ""))
                    if record.get("status") == "done":
                        self.log_markdown(
                            body, label_markup="[b green]agent:[/b green]", mirror_label="agent:"
                        )
                    else:
                        self.log_plain(
                            body, label_markup="[b red]agent:[/b red] ", mirror_label="agent:"
                        )
                elif kind == "slash-result":
                    self.log_fenced(
                        str(record.get("text", "")),
                        label_markup="[b green]result:[/b green]",
                        mirror_label="result:",
                        lang="json",
                    )

        def finish_worker_error(self, exc: Exception, stack: str = "") -> None:
            """Return the UI to an actionable state after an unexpected worker error."""
            if self.shutting_down:
                return
            detail = f"{type(exc).__name__}: {exc}"
            self.session.append({"t": "worker-error", "text": detail})
            self.log_plain(
                detail,
                label_markup="[b red]console error:[/b red] ",
                mirror_label="console error:",
            )
            if stack and os.environ.get("MKLANG_DEBUG") == "1":
                self.log_plain(
                    stack,
                    label_markup="[dim]traceback:[/dim] ",
                    mirror_label="traceback:",
                )
            self.running = False
            self.answer_mode = False
            box = self.query_one("#prompt", Input)
            box.disabled = False
            box.placeholder = "Ask the agent or type / for commands"
            box.remove_class("answer-mode")
            self.update_status("error")
            box.focus()

        def on_resize(self, _event: object) -> None:
            self.apply_responsive_layout()

        def apply_responsive_layout(self) -> None:
            body = self.query_one("#body")
            main = self.query_one("#main")
            panel = self.query_one(Inspector)
            body.remove_class("inspector-wide", "inspector-narrow")
            if not self.inspector_visible:
                main.display = True
                panel.display = True
                panel.styles.visibility = "hidden"
                panel.styles.width = 0
            elif self.size.width >= 100:
                body.add_class("inspector-wide")
                main.display = True
                panel.display = True
                panel.styles.visibility = "visible"
                panel.styles.width = "40%"
                panel.styles.min_width = 32
                panel.styles.max_width = 46
            else:
                body.add_class("inspector-narrow")
                main.display = False
                panel.display = True
                panel.styles.visibility = "visible"
                panel.styles.width = "100%"
                panel.styles.min_width = 0
                panel.styles.max_width = None

        # -- rendering -----------------------------------------------------

        def log_write(self, renderable: RenderableType, mirror: str) -> None:
            """Write a Rich renderable and append a plain-text mirror for tests."""
            self.query_one("#log", RichLog).write(renderable)
            self.log_history.append(mirror)

        def log_chrome(self, markup: str) -> None:
            """Internal-only Rich markup (no untrusted interpolation)."""
            self.log_write(log_render.chrome(markup), markup)

        def log_plain(self, body: str, *, label_markup: str, mirror_label: str) -> None:
            """Chrome label + plain untrusted body."""
            self.log_write(
                log_render.labeled_plain(label_markup, body),
                f"{mirror_label} {body}" if body else mirror_label,
            )

        def log_markdown(self, body: str, *, label_markup: str, mirror_label: str) -> None:
            """Chrome label + CommonMark body (agent prose)."""
            self.log_write(
                log_render.labeled_markdown(label_markup, body),
                f"{mirror_label} {body}" if body else mirror_label,
            )

        def log_fenced(
            self,
            body: str,
            *,
            label_markup: str | None = None,
            mirror_label: str = "",
            lang: str = "",
        ) -> None:
            """Fenced code (JSON / machine source); optional chrome label."""
            if label_markup:
                self.log_write(
                    log_render.labeled_fenced(label_markup, body, lang=lang),
                    f"{mirror_label} {body}" if mirror_label else body,
                )
            else:
                self.log_write(log_render.fenced(body, lang=lang), body)

        def update_status(self, state: str | None = None) -> None:
            state = state or ("running" if self.running else "ready")
            status = self.query_one("#status", Static)
            status.remove_class("ready", "running", "waiting", "stopping", "error")
            status.add_class(state)
            status.update(
                log_render.status_line(
                    state,
                    self.tools.prov.name,
                    self.current_phase,
                    self.spent_in,
                    self.spent_out,
                    self.session.id,
                    self.current_limits,
                )
            )

        def render_event(self, e: dict) -> None:
            # Delta events are rendered in-place; lifecycle events are the
            # compact durable checkpoints. Never persist generated chunks.
            if e["type"] != "llm-delta":
                self.session.append({"t": "event", **e})
            if e["type"] == "llm-start":
                self._live_request = {
                    "operation": e.get("operation", "llm"),
                    "model": e.get("model", ""),
                    "tier": e.get("tier", ""),
                    "phase": "thinking" if e.get("operation") == "produce" else "judging",
                    "started": time.monotonic(),
                    "first_delta": None,
                    "retries": 0,
                    "output": "",
                }
                self.refresh_live_activity()
            elif e["type"] == "llm-delta":
                if self._live_request:
                    if self._live_request["first_delta"] is None:
                        self._live_request["first_delta"] = round(
                            (time.monotonic() - self._live_request["started"]) * 1000
                        )
                    if e.get("delta_kind") == "content":
                        self._live_request["phase"] = "generating"
                        self._live_request["output"] = (
                            self._live_request["output"] + str(e.get("delta", ""))
                        )[-4000:]
                    else:
                        self._live_request["phase"] = "thinking"
                    self.refresh_live_activity()
            elif e["type"] == "llm-retry" and self._live_request:
                self._live_request["phase"] = "retrying"
                self._live_request["retries"] += 1
                self.refresh_live_activity()
            elif e["type"] in ("llm-done", "llm-error") and self._live_request:
                self._live_request["phase"] = "done" if e["type"] == "llm-done" else "error"
                self._live_request.update(e)
                self.refresh_live_activity()
            if e["type"] == "state-start":
                self.current_phase = str(e.get("state") or "working")
                self.update_status("waiting" if e.get("kind") == "tool" else "running")
            if e["type"] == "run-start" and not e.get("run"):
                self.current_limits = e.get("limits") or self.current_limits
                self.update_status()
            if e["type"] == "state-done":
                tokens = e.get("tokens") or {}
                self.spent_in += tokens.get("input_tokens", 0)
                self.spent_out += tokens.get("output_tokens", 0)
                self.update_status()
            if e["type"] == "run-finished":
                self.current_phase = ""
                self.current_limits = e.get("limits") or self.current_limits
                self.clear_live_activity()
            self.query_one(ActivityTree).feed(e)

        def clear_live_activity(self) -> None:
            """Remove transient provider output once the durable result is rendered."""
            self._live_request = {}
            live_widgets = list(self.query("#activity-live"))
            if live_widgets:
                cast(Static, live_widgets[0]).update(log_render.activity_live_idle())

        def refresh_live_activity(self) -> None:
            if not self._live_request:
                return
            live_widgets = list(self.query("#activity-live"))
            if not live_widgets:
                # Textual timers can tick during screen teardown; late progress
                # must not turn a clean shutdown into a NoMatches exception.
                return
            req = self._live_request
            elapsed = req.get("elapsed_ms")
            if elapsed is None:
                elapsed = round((time.monotonic() - req["started"]) * 1000)
            cast(Static, live_widgets[0]).update(
                log_render.activity_live(
                    req.get("operation", "llm"),
                    req.get("phase", "working"),
                    req.get("model", ""),
                    req.get("tier", ""),
                    int(elapsed),
                    req.get("first_delta"),
                    int(req.get("retries", 0)),
                    req.get("output", ""),
                )
            )

        # -- human input ----------------------------------------------------

        def enter_answer_mode(self, question: str) -> None:
            self.answer_mode = True
            # Question text is untrusted (brain / tool / HITL); keep it plain.
            self.log_plain(question, label_markup="[yellow]⏸ [/yellow]", mirror_label="⏸")
            box = self.query_one("#prompt", Input)
            # Consent prompts include "type y"; keep a short generic placeholder.
            box.placeholder = "answer here, then Enter…"
            box.add_class("answer-mode")
            box.disabled = False
            box.focus()

        def on_input_submitted(self, event: Input.Submitted) -> None:
            text = event.value.strip()
            box = self.query_one("#prompt", Input)
            box.value = ""
            if self.answer_mode:
                self.answer_mode = False
                box.placeholder = "Ask the agent or type / for commands"
                box.remove_class("answer-mode")
                self.log_plain(text, label_markup="[yellow]you:[/yellow] ", mirror_label="you:")
                box.disabled = True
                self.bridge.deliver(text)
                return
            if not text:
                return
            if text.startswith("/"):
                self.handle_slash(text)
                return
            self.log_plain(text, label_markup="[b cyan]you:[/b cyan] ", mirror_label="you:")
            self.session.append({"t": "user", "text": text})
            self.query_one(ActivityTree).new_turn(text[:60])
            box.disabled = True
            self.running = True
            self.cancel_event.clear()
            self.current_limits = {}
            self.update_status("running")
            self._run_thread_worker(lambda: self.turn(text))

        # -- slash commands (operator affordances, bypass the brain) ---------

        def handle_slash(self, text: str) -> None:
            import json as _json

            from ..checkpoint import load_checkpoint
            from .commands import BY_NAME, help_text, parse_assignments, parse_command

            try:
                cmd, args = parse_command(text)
            except ValueError as exc:
                self.log_plain(
                    str(exc),
                    label_markup="[red]command error:[/red] ",
                    mirror_label="command error:",
                )
                return
            if cmd == "/help":
                self.log_fenced(help_text())
            elif cmd == "/machines":
                rows = _json.loads(self.tools.list_machines({}))["machines"]
                for r in rows:
                    # Name/keys are host data but still not interpolated into markup tags.
                    keys = ", ".join(r["context_keys"]) or "—"
                    suffix = f" · result={r['result']} · budget={r['budget']} · keys={keys}"
                    self.log_write(
                        log_render.bold_name_line(r["name"], suffix),
                        f"  {r['name']}{suffix}",
                    )
                if not rows:
                    self.log_chrome("[dim]no machines[/dim]")
            elif cmd == "/run" and args:
                target = args[0]
                try:
                    inputs = parse_assignments(args[1:])
                except ValueError as exc:
                    self.log_plain(
                        str(exc),
                        label_markup="[red]command error:[/red] ",
                        mirror_label="command error:",
                    )
                    return
                self.log_plain(
                    f"{target} {inputs or ''}".rstrip(),
                    label_markup="[b cyan]/run[/b cyan] ",
                    mirror_label="/run",
                )
                self.query_one(ActivityTree).new_turn(f"/run {target}")
                self.query_one("#prompt", Input).disabled = True
                self.running = True
                self.cancel_event.clear()
                self.current_limits = {}
                self.update_status("running")
                self._run_thread_worker(lambda: self.slash_run(target, inputs))
            elif cmd == "/check" and args:
                verdict = _json.loads(self.tools.check_machine({"name": args[0]}))
                payload = _json.dumps(verdict, ensure_ascii=False, indent=2)
                self.log_fenced(payload, lang="json")
            elif cmd == "/read" and args:
                source = self.tools.read_machine({"name": args[0]})
                self.log_fenced(source, lang="yaml")
            elif cmd == "/budget" and args:
                try:
                    budget = int(args[0])
                    if budget <= 0:
                        raise ValueError
                    self.tools.default_cost_budget = budget
                    self.log_chrome(f"[dim]default cost budget → {args[0]} tokens[/dim]")
                except ValueError:
                    self.log_chrome("[red]/budget needs an integer[/red]")
            elif cmd == "/session":
                self.log_chrome(
                    f"[dim]session {self.session.id} · {self.session.dir} · "
                    f"tokens {self.spent_in}+{self.spent_out}[/dim]"
                )
            elif cmd == "/provider":
                tiers = (
                    ", ".join(
                        f"{name}={model}" for name, model in sorted(self.tools.prov.tiers.items())
                    )
                    or "—"
                )
                self.log_chrome(
                    f"[dim]provider {self.tools.prov.name} · judge "
                    f"{self.tools.prov.judge_override() or 'per-tier'} · tiers {tiers}[/dim]"
                )
            elif cmd == "/clear":
                self.action_clear_log()
                self.query_one(ActivityTree).new_turn("cleared")
            elif cmd == "/resume":
                cks = sorted(self.session.checkpoints_dir.glob("*.json"))
                if not args:
                    if not cks:
                        self.log_chrome("[dim]no parked checkpoints in this session[/dim]")
                    for i, ck in enumerate(cks):
                        self.log_plain(ck.name, label_markup=f"  [[{i}]] ", mirror_label=f"  [{i}]")
                    return
                try:
                    ck_doc = load_checkpoint(cks[int(args[0])])
                    overrides = parse_assignments(args[1:])
                except (IndexError, KeyError, TypeError, ValueError, OSError) as e:
                    self.log_plain(
                        str(e),
                        label_markup="[red]cannot resume:[/red] ",
                        mirror_label="cannot resume:",
                    )
                    return
                name = cks[int(args[0])].name
                self.log_plain(
                    name, label_markup="[b cyan]/resume[/b cyan] ", mirror_label="/resume"
                )
                self.query_one(ActivityTree).new_turn("/resume")
                self.query_one("#prompt", Input).disabled = True
                self._run_thread_worker(lambda: self.slash_resume(ck_doc, overrides))
            elif cmd == "/quit":
                _ = self.run_action("quit")
            elif cmd in ("/run", "/check", "/read", "/budget"):
                self.log_plain(
                    f"usage: {BY_NAME[cmd].usage}",
                    label_markup="[red]missing argument:[/red] ",
                    mirror_label="missing argument:",
                )
            else:
                self.log_chrome(f"[red]unknown command {cmd} — try /help[/red]")

        def slash_run(self, target: str, inputs: dict) -> None:
            import json as _json

            obs = self.tools.run_machine({"target": target, "inputs": _json.dumps(inputs)})
            if not self.shutting_down:
                self.call_from_thread(self.finish_slash, obs)

        def slash_resume(self, ck: dict, overrides: dict | None = None) -> None:
            frame_steps = max((int(f.get("steps", 0)) for f in ck["frames"]), default=0)
            step_limit = (
                int(overrides.get("steps", frame_steps + 8)) if overrides else frame_steps + 8
            )
            token_limit = (
                int(overrides["tokens"])
                if overrides and "tokens" in overrides
                else ck.get("cost_budget")
            )
            machine = dc_replace(brain, budget=step_limit)
            res = self._run_brain(
                machine,
                self._inject_workspace_context(dict(machine.context)),
                resume=ck["frames"],
                cost_budget=token_limit,
            )
            if not self.shutting_down:
                self.call_from_thread(self.finish_turn, "(resumed turn)", res)

        def finish_slash(self, observation: str) -> None:
            if self.shutting_down:
                return
            # Observations are JSON envelopes — fence them, do not full-MD parse.
            self.log_fenced(
                observation,
                label_markup="[b green]result:[/b green]",
                mirror_label="result:",
                lang="json",
            )
            self.session.append({"t": "slash-result", "text": observation})
            self.session.save_state()
            self.running = False
            self.update_status("ready")
            box = self.query_one("#prompt", Input)
            box.disabled = False
            box.remove_class("answer-mode")
            box.focus()

        # -- the agent turn (worker thread) ----------------------------------

        def _run_brain(self, machine, ctx, resume=None, cost_budget=_DEFAULT_COST_BUDGET):
            brain_tools = self.tools.as_tool_registry()
            # Keep lightweight engine seams usable by embedders/tests that pass
            # a prepared machine-like object instead of a parsed Machine.
            if isinstance(machine, Machine):
                self.tools.preflight(machine, tools_registry=brain_tools)
            return run_engine(
                machine,
                ctx,
                self.tools.machine_registry(machine),
                self.tools.llm,
                self.tools.prov.tiers,
                self.tools.prov.judge_override(),
                tier_params=self.tools.prov.params,
                tools=brain_tools,
                hooks=load_hook_registry(),
                cost_budget=(
                    self.tools.default_cost_budget
                    if cost_budget is _DEFAULT_COST_BUDGET
                    else cost_budget
                ),
                suspendable=True,
                resume=resume,
                on_event=self.bridge.emit,
                stream=True,
                stream_cancel=self.stream_cancel,
                cancel_requested=self.cancel_event.is_set,
                # The brain runs under the same host policies as the machines it
                # commissions; both default to "report", so this changes nothing
                # until an embedder asks for stricter. Note what `halt` would mean
                # here: the operator's own message is external data like any other
                # host input, so every brain decision is tainted and every
                # effectful console tool (write_machine, run_machine, update_task)
                # would be refused. That is a deliberate lockdown, not a default.
                on_truncate=self.tools.on_truncate,
                on_untrusted_flow=self.tools.on_untrusted_flow,
            )

        def _inject_workspace_context(self, ctx: dict) -> dict:
            """Add host-selected workspace facts to every brain execution path."""
            ctx["workspace_root"] = str(self.tools.workspace)
            return ctx

        def turn(self, user_message: str) -> None:
            # Full history stays on the session for audit; only a windowed view
            # is injected into the brain (ADR 0017 console history budget).
            from .. import host as host_mod
            from .session import history_for_brain

            ctx = self._inject_workspace_context(
                {
                    **brain.context,
                    "user_message": user_message,
                    "history": history_for_brain(self.history),
                    "observation": [],
                    "workspace_context": self.tools.workspace_context(),
                    "workspace_brief": "",
                    "workspace_required": requires_workspace_inspection(user_message),
                    "task_state": dict(self.session.task),
                }
            )
            host_mod.inject_host_defaults(ctx)  # brain may declare context.today
            machine = brain
            res = self._run_brain(machine, ctx)
            # Budget exhaustion is a UI moment: extend the exhausted dimension
            # explicitly, or park a checkpoint for a later /resume.
            while res.status == "suspended" and res.error in {
                "budget-exhausted",
                "cost-exhausted",
            }:
                limits = res.limits or {}
                step_info = limits.get("steps", {})
                token_info = limits.get("tokens", {})
                answer = self.bridge.ask(
                    f"{res.error}: steps {step_info.get('used', 0)}/{step_info.get('limit', '∞')}, "
                    f"tokens {token_info.get('used', 0)}/{token_info.get('limit', '∞')}. "
                    "Enter new total limits as steps=N tokens=N (Enter/n = park)."
                )
                if not answer.strip() or answer.strip().lower() in {"n", "no", "park"}:
                    ck = self.session.checkpoints_dir / f"turn-{datetime.now():%H%M%S-%f}.json"
                    save_checkpoint(
                        ck,
                        machine.name,
                        "<console-brain>",
                        res.error,
                        res.frames,
                        token_info.get("limit"),
                        step_budget=machine.budget,
                    )
                    break
                try:
                    requested = {
                        item.split("=", 1)[0].strip().lower(): item.split("=", 1)[1].strip()
                        for item in answer.replace(",", " ").split()
                        if "=" in item
                    }
                    step_limit = int(requested.get("steps", step_info.get("limit")))
                    raw_tokens = requested.get("tokens", token_info.get("limit"))
                    token_limit = None if raw_tokens in (None, "", "none", "∞") else int(raw_tokens)
                    if step_limit <= step_info.get("used", 0) or (
                        token_limit is not None and token_limit <= token_info.get("used", 0)
                    ):
                        raise ValueError
                except (TypeError, ValueError):
                    self.log_chrome("[red]use positive total limits: steps=N tokens=N[/red]")
                    continue
                machine = dc_replace(machine, budget=step_limit)
                res = self._run_brain(
                    machine,
                    self._inject_workspace_context(dict(machine.context)),
                    resume=res.frames,
                    cost_budget=token_limit,
                )
            if not self.shutting_down:
                self.call_from_thread(self.finish_turn, user_message, res)

        def finish_turn(self, user_message: str, res: RunResult) -> None:
            if self.shutting_down:
                return
            if res.status == "done":
                body = str(res.result or "")
                self.log_markdown(
                    body, label_markup="[b green]agent:[/b green]", mirror_label="agent:"
                )
                self.history += f"\nuser: {user_message}\nagent: {res.result}"
            else:
                detail = f"{res.error} (at {res.at})"
                self.log_plain(
                    detail,
                    label_markup=f"[b red]agent {res.status}:[/b red] ",
                    mirror_label=f"agent {res.status}:",
                )
            self.session.append(
                {"t": "agent", "status": res.status, "text": str(res.result or res.error)}
            )
            panel = self.query_one(Inspector)
            panel.show_result(res)
            panel.show_session(self.session, self.spent_in, self.spent_out, self.tools.consented)
            self.session.history = self.history
            self.session.spent_in = self.spent_in
            self.session.spent_out = self.spent_out
            self.session.consented = sorted(self.tools.consented)
            self.session.save_state()
            self.running = False
            self.update_status("ready")
            box = self.query_one("#prompt", Input)
            box.disabled = False
            box.remove_class("answer-mode")
            box.focus()

    return ConsoleApp()


def main(
    config: str,
    provider: str | None,
    workspace: str,
    agent_path: str | None,
    continue_session: bool = False,
    session_id: str | None = None,
) -> int:
    app = build_app(
        config,
        provider,
        workspace,
        agent_path,
        continue_session=continue_session,
        session_id=session_id,
    )
    app.run()
    return 0
